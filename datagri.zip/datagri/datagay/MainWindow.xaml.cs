﻿using System;
using System.Collections.ObjectModel;
using System.Windows;

namespace datagay
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<player> SeznamHracu { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            SeznamHracu = new ObservableCollection<player>();
            Playersgrid.ItemsSource = SeznamHracu;

            SeznamHracu.Add(new player("kubasenda", "Heavy", 17869, 16678));
            SeznamHracu.Add(new player("Lycommit", "Medium", 182643, 51877));
            SeznamHracu.Add(new player("UNI", "Light", 123872, 29783));
        }

        private void NumberValidation(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text[0])) e.Handled = true;
        }

        private void LoadPlayer_Click(object sender, RoutedEventArgs e)
        {
            player p = (player)Playersgrid.SelectedItem;
            if (p != null)
            {
                TxtUsername.Text = p.Username;
                ComboClass.Text = p.Class;
                TxtKills.Text = p.Kills.ToString();
                TxtDeaths.Text = p.Deaths.ToString();
            }
        }

        private void AddPlayer_Click(object sender, RoutedEventArgs e)
        {
            string user = TxtUsername.Text;
            string classa = ComboClass.Text;
            int kills = int.Parse(TxtKills.Text);
            int deaths = int.Parse(TxtDeaths.Text);
            SeznamHracu.Add(new player(user,classa, kills, deaths));
        }

        private void EditPlayer_Click(object sender, RoutedEventArgs e)
        {
            player p = (player)Playersgrid.SelectedItem;
            if (p != null)
            {
                p.Username = TxtUsername.Text;
                p.Class = ComboClass.Text;
                p.Kills = int.Parse(TxtKills.Text);
                p.Deaths = int.Parse(TxtDeaths.Text);
                if (p.Deaths > 0)
                {
                    p.KD = Math.Round((double)p.Kills / p.Deaths, 2);
                }
                else
                {
                    p.KD = double.PositiveInfinity;
                }
                Playersgrid.Items.Refresh();
            }
        }

        private void DataGrid_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e) { }
    }
}