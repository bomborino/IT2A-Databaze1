﻿using System;

namespace datagay
{
    public class player
    {
        public string Username { get; set; }
        public string Class { get; set; }
        public int Kills { get; set; }
        public int Deaths { get; set; }
        public double KD { get; set; }
    

        public player(string username, string cllass, int kills, int deaths)
        {
            Username = username;
            Class = cllass;
            Kills = kills;
            Deaths = deaths;
            if (deaths > 0)
            {
                KD = Math.Round((double)Kills / Deaths, 2);
            }
            else
            {
                KD = double.PositiveInfinity;
            }
        }
    }
}